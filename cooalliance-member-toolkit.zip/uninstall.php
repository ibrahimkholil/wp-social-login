<?php
/**
 * Trigger this file on plugin uninstall
 */


 if (! defined('WP_UNINSTALL_PLUGIN')) {
     die();
 }
